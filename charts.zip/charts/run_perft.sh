#!/bin/bash

# below function required for k3s deployment
kubectl() {
 sudo KUBECONFIG=/home/k3s/.kube/k3s.yaml /usr/local/bin/k3s kubectl $*
}


# create a separate namespace to deploy tools requiring privilege access
kubectl create ns tools

# add pod security label to allow running privilege container
kubectl label --overwrite ns tools  pod-security.kubernetes.io/enforce=privileged pod-security.kubernetes.io/warn=privileged pod-security.kubernetes.i
o/audit=privileged

# install chart for tools
sudo KUBECONFIG=/home/k3s/.kube/k3s.yaml /usr/local/bin/helm install --namespace tools perft ./perft/

# uninstall chart tools
#sudo KUBECONFIG=/home/k3s/.kube/k3s.yaml /usr/local/bin/helm uninstall perft -n tools

